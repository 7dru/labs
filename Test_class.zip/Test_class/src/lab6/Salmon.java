package lab6;

public class Salmon extends Fish{
	public Salmon(String name, double weight, double maxDepth) {
		super(name, weight, maxDepth);
	}
 public void swim() {
	 System.out.println("I return to rivers from the ocean and swim upstream to my original hatching place to lay and fertilize my eggs.");
 }
 @Override
 public String toString() {
	return  super.toString() + "-";
 }
 
}
