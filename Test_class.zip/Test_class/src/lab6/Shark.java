package lab6;

public class Shark extends Fish{
	private int gestationPeriod;

	public Shark(String name, double weight, double maxDepth, int gestationPeriod) {
		super(name, weight, maxDepth);
		this.gestationPeriod=gestationPeriod;
}
	public void swim() {
	System.out.println(" I can swim in salt and fresh water and even in the Mississipi river. ");
	}
	public int getGestationPeriod() {
		return gestationPeriod;
	}
	public void setGestationPeriod(int gestationPeriod) {
		this.gestationPeriod = gestationPeriod;
	}
	@Override
	public String toString() {
		return "Shark [gestationPeriod=" + gestationPeriod + ", toString()=" + super.toString() + "]";
	}
	
}
