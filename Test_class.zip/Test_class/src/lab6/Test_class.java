package lab6;

public class Test_class {

	public static void main(String[] args) {
		Fish[] list = new Fish[3];
	list[0] = new Shark("Shark_1", 2000.0, 1200.0, 12);
	list[1] = new Salmon("Salmon_1", 1.6, 0.36);
	list[2] = new Salmon("Salmon_2", 1.8, 0.46);
	for(int i = 0; i < list.length; i++) {
		list[i].swim();
	}
	for(int i = 0; i < list.length; i++) {
		System.out.println(list[i]);
	}
	}
}
