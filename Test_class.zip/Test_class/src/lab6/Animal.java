package lab6;

public abstract class Animal {
	private String name;
	protected  double weight;
	public Animal(String name, double weight) {
		super();
		this.name = name;
		this.weight = weight;
	}
	public abstract void swim();
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getWeight() {
		return weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}
	@Override
	public String toString() {
		return "Animal [name=" + name + ", weight=" + weight + "]";
	}
	

}
