package lab6;

public abstract class Fish extends Animal{
	protected double maxDepth;

	public Fish(String name, double weight, double maxDepth) {
		super(name, weight);
		this.maxDepth = maxDepth;
	}

	public double getMaxDepth() {
		return maxDepth;
	}

	public void setMaxDepth(double maxDepth) {
		this.maxDepth = maxDepth;
	}

	@Override
	public String toString() {
		return "Fish [maxDepth=" + maxDepth + ", toString()=" + super.toString() + "]";
	}
	
	}


	


