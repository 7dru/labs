package lab8;

public class Recursive {
	public static int POW(int n, int x) {
		if(x == 0)
			return 1;
	return n * POW(n, x-1);
	}
	public static void main(String[] args) {
	int result = POW(4,2);
	 System.out.println("POW(4,2)");
	 System.out.println("THE RESULT=" +result);
	}
}
	
